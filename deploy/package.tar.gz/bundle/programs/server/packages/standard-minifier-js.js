(function () {



/* Exports */
Package._define("standard-minifier-js");

})();
