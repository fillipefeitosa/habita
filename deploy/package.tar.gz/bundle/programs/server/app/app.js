var require = meteorInstall({"imports":{"api":{"charts":{"server":{"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/charts/server/publications.js                                           //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Charts;
module.link("../charts.js", {
  Charts(v) {
    Charts = v;
  }

}, 1);
Meteor.publish('Charts', function () {
  return Charts.find({});
});
/////////////////////////////////////////////////////////////////////////////////////////

}},"charts.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/charts/charts.js                                                        //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.export({
  Charts: () => Charts
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let AutoForm;
module.link("meteor/aldeed:autoform", {
  AutoForm(v) {
    AutoForm = v;
  }

}, 2);
let Images;
module.link("../images/images.js", {
  Images(v) {
    Images = v;
  }

}, 3);
SimpleSchema.extendOptions(['autoform']);
const Charts = new Mongo.Collection('Charts');
Charts.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  },
  remove: function () {
    return true;
  }
});
ChartsSchema = new SimpleSchema({
  name: {
    type: String,
    label: 'Nome do Gráfico',
    max: 30
  },
  available: {
    type: Boolean,
    optional: true
  },
  picture: {
    type: String,
    autoform: {
      afFieldInput: {
        type: 'fileUpload',
        collection: 'Images',
        // uploadTemplate: 'uploadField', // <- Optional
        // previewTemplate: 'uploadPreview', // <- Optional
        insertConfig: {
          // <- Optional, .insert() method options, see: https://github.com/VeliovGroup/Meteor-Files/wiki/Insert-(Upload)
          meta: {},
          isBase64: false,
          transport: 'ddp',
          streams: 'dynamic',
          chunkSize: 'dynamic',
          allowWebWorkers: true
        }
      }
    }
  }
});
Charts.attachSchema(ChartsSchema);
/////////////////////////////////////////////////////////////////////////////////////////

}},"images":{"server":{"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/images/server/publications.js                                           //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
// import { Meteor } from 'meteor/meteor';
// import { Images } from '../images.js';
//
// if (Meteor.isServer) {
//   Meteor.publish('files.images.all', function () {
//     return Images.find().cursor;
//   });
// }
/////////////////////////////////////////////////////////////////////////////////////////

}},"images.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/images/images.js                                                        //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.export({
  Images: () => Images
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let FilesCollection;
module.link("meteor/ostrio:files", {
  FilesCollection(v) {
    FilesCollection = v;
  }

}, 1);
const Images = new FilesCollection({
  collectionName: 'Images',
  allowClientCode: true,
  // Required to let you remove uploaded file,
  storagePath: '/var/www/urbanus/public/images',

  //must be the same on dockerfile
  onBeforeUpload(file) {
    // Allow upload files under 10MB, and only in png/jpg/jpeg formats
    if (file.size <= 10485760 && /png|jpg|jpeg/i.test(file.ext)) {
      return true;
    } else {
      return 'Please upload image, with size equal or less than 10MB';
    }
  }

});

if (Meteor.isClient) {
  Meteor.subscribe('files.images.all');
}

if (Meteor.isServer) {
  Meteor.publish('files.images.all', () => {
    return Images.collection.find({});
  });
}
/////////////////////////////////////////////////////////////////////////////////////////

}},"links":{"server":{"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/links/server/publications.js                                            //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Links;
module.link("../links.js", {
  Links(v) {
    Links = v;
  }

}, 1);
Meteor.publish('links.all', function () {
  return Links.find();
});
/////////////////////////////////////////////////////////////////////////////////////////

}},"links.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/links/links.js                                                          //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.export({
  Links: () => Links
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Links = new Mongo.Collection('links');
/////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/links/methods.js                                                        //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }

}, 1);
let Links;
module.link("./links.js", {
  Links(v) {
    Links = v;
  }

}, 2);
Meteor.methods({
  'links.insert'(title, url) {
    check(url, String);
    check(title, String);
    return Links.insert({
      url,
      title,
      createdAt: new Date()
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////

}},"maps":{"server":{"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/maps/server/publications.js                                             //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Maps;
module.link("../maps.js", {
  Maps(v) {
    Maps = v;
  }

}, 1);
Maps.allowClient();
Meteor.publish("files.maps.all", function (argument) {
  return Maps.collection.find({});
});
/////////////////////////////////////////////////////////////////////////////////////////

}},"maps.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/maps/maps.js                                                            //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.export({
  Maps: () => Maps
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let FilesCollection;
module.link("meteor/ostrio:files", {
  FilesCollection(v) {
    FilesCollection = v;
  }

}, 1);
module.link("./methods.js");
const Maps = new FilesCollection({
  collectionName: 'Maps',
  allowClientCode: true,
  downloadRoute: '/public/',

  onBeforeUpload(file) {
    if (file.size <= 10485760 && /json|geojson/i.test(file.extension)) {
      return true;
    }

    return 'Favor fazer upload de geojson válido';
  }

});
/////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/maps/methods.js                                                         //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let Maps;
module.link("./maps.js", {
  Maps(v) {
    Maps = v;
  }

}, 2);
Meteor.methods({
  getMapLink: function (mapId) {
    validadeId = new SimpleSchema({
      mapId: {
        type: String
      }
    });
    SimpleSchema.validate(mapId, validadeId, {
      keys: ["mapId"]
    });
    console.log(mapId);
    myMap = Maps.collection.find(mapId["mapId"]);
    return myMap;
  }
});
/////////////////////////////////////////////////////////////////////////////////////////

}},"tasks":{"server":{"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/tasks/server/publications.js                                            //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Tasks;
module.link("../tasks.js", {
  Tasks(v) {
    Tasks = v;
  }

}, 1);
Meteor.publish('tasks.all', function () {
  return Tasks.find();
});
/////////////////////////////////////////////////////////////////////////////////////////

}},"tasks.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/tasks/tasks.js                                                          //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.export({
  Tasks: () => Tasks
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Tasks = new Mongo.Collection('tasks');
/////////////////////////////////////////////////////////////////////////////////////////

}},"team":{"server":{"publications.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/team/server/publications.js                                             //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Team;
module.link("../team.js", {
  Team(v) {
    Team = v;
  }

}, 1);
Meteor.publish('Team', function () {
  return Team.find({});
});
/////////////////////////////////////////////////////////////////////////////////////////

}},"team.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/api/team/team.js                                                            //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.export({
  Team: () => Team
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let AutoForm;
module.link("meteor/aldeed:autoform", {
  AutoForm(v) {
    AutoForm = v;
  }

}, 2);
let Images;
module.link("../images/images.js", {
  Images(v) {
    Images = v;
  }

}, 3);
SimpleSchema.extendOptions(['autoform']);
const Team = new Mongo.Collection('Team');
Team.allow({
  insert: function () {
    return true;
  },
  update: function () {
    return true;
  },
  remove: function () {
    return true;
  }
});
TeamSchema = new SimpleSchema({
  name: {
    type: String,
    label: "Nome",
    max: 200
  },
  formation: {
    type: String,
    label: 'Formação',
    optional: true,
    max: 100
  },
  link: {
    type: String,
    label: "Link",
    max: 200
  },
  picture: {
    type: String,
    autoform: {
      afFieldInput: {
        type: 'fileUpload',
        collection: 'Images',
        // uploadTemplate: 'uploadField', // <- Optional
        // previewTemplate: 'uploadPreview', // <- Optional
        insertConfig: {
          // <- Optional, .insert() method options, see: https://github.com/VeliovGroup/Meteor-Files/wiki/Insert-(Upload)
          meta: {},
          isBase64: false,
          transport: 'ddp',
          streams: 'dynamic',
          chunkSize: 'dynamic',
          allowWebWorkers: true
        }
      }
    }
  }
});
Team.attachSchema(TeamSchema);
/////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/startup/both/index.js                                                       //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
// Import modules used by both client and server through a single index entry point
// e.g. useraccounts configuration file.
/////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"fixtures.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/startup/server/fixtures.js                                                  //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Links;
module.link("../../api/links/links.js", {
  Links(v) {
    Links = v;
  }

}, 1);
let Roles;
module.link("meteor/alanning:roles", {
  Roles(v) {
    Roles = v;
  }

}, 2);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 3);
Meteor.startup(() => {
  // Set Conf for autoform-files <https://github.com/VeliovGroup/meteor-autoform-file>
  SimpleSchema.setDefaultMessages({
    initialLanguage: 'en',
    messages: {
      en: {
        uploadError: '{{value}}' //File-upload

      }
    }
  }); // If the Roles collection is empty

  var roles = Meteor.roles.find({}).count();

  if (roles > 0) {
    console.log("Roles Defined. Default Behavior.");
  } else {
    Roles.createRole('Convidado');
    Roles.createRole('Colaborador');
    Roles.createRole('Administrador');
  } // Make new user as 'Convidado role'


  Accounts.onCreateUser(function (options, user) {
    user.roles = ['Convidado'];
    return user;
  }); // if the Links collection is empty

  if (Links.find().count() === 0) {
    const data = [{
      title: 'Do the Tutorial',
      url: 'https://www.meteor.com/try',
      createdAt: new Date()
    }, {
      title: 'Follow the Guide',
      url: 'http://guide.meteor.com',
      createdAt: new Date()
    }, {
      title: 'Read the Docs',
      url: 'https://docs.meteor.com',
      createdAt: new Date()
    }, {
      title: 'Discussions',
      url: 'https://forums.meteor.com',
      createdAt: new Date()
    }];
    data.forEach(link => Links.insert(link));
  }
});
/////////////////////////////////////////////////////////////////////////////////////////

},"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/startup/server/index.js                                                     //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.link("./fixtures.js");
module.link("./register-api.js");
/////////////////////////////////////////////////////////////////////////////////////////

},"register-api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// imports/startup/server/register-api.js                                              //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.link("../../api/links/methods.js");
module.link("../../api/links/server/publications.js");
module.link("../../api/tasks/tasks.js");
module.link("../../api/tasks/server/publications.js");
module.link("../../api/team/team.js");
module.link("../../api/team/server/publications.js");
module.link("../../api/charts/charts.js");
module.link("../../api/charts/server/publications.js");
module.link("../../api/images/images.js");
module.link("../../api/images/server/publications.js");
module.link("../../api/maps/maps.js");
module.link("../../api/maps/server/publications.js");
/////////////////////////////////////////////////////////////////////////////////////////

}}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////
//                                                                                     //
// server/main.js                                                                      //
//                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////
                                                                                       //
module.link("/imports/startup/server");
module.link("/imports/startup/both");
/////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY2hhcnRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2NoYXJ0cy9jaGFydHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL2ltYWdlcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9pbWFnZXMvaW1hZ2VzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9saW5rcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9saW5rcy9saW5rcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbGlua3MvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbWFwcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2FwaS9tYXBzL21hcHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21hcHMvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdGFza3Mvc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdGFza3MvdGFza3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL3RlYW0vc2VydmVyL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvdGVhbS90ZWFtLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvYm90aC9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9maXh0dXJlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9yZWdpc3Rlci1hcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiQ2hhcnRzIiwicHVibGlzaCIsImZpbmQiLCJleHBvcnQiLCJNb25nbyIsIlNpbXBsZVNjaGVtYSIsImRlZmF1bHQiLCJBdXRvRm9ybSIsIkltYWdlcyIsImV4dGVuZE9wdGlvbnMiLCJDb2xsZWN0aW9uIiwiYWxsb3ciLCJpbnNlcnQiLCJ1cGRhdGUiLCJyZW1vdmUiLCJDaGFydHNTY2hlbWEiLCJuYW1lIiwidHlwZSIsIlN0cmluZyIsImxhYmVsIiwibWF4IiwiYXZhaWxhYmxlIiwiQm9vbGVhbiIsIm9wdGlvbmFsIiwicGljdHVyZSIsImF1dG9mb3JtIiwiYWZGaWVsZElucHV0IiwiY29sbGVjdGlvbiIsImluc2VydENvbmZpZyIsIm1ldGEiLCJpc0Jhc2U2NCIsInRyYW5zcG9ydCIsInN0cmVhbXMiLCJjaHVua1NpemUiLCJhbGxvd1dlYldvcmtlcnMiLCJhdHRhY2hTY2hlbWEiLCJGaWxlc0NvbGxlY3Rpb24iLCJjb2xsZWN0aW9uTmFtZSIsImFsbG93Q2xpZW50Q29kZSIsInN0b3JhZ2VQYXRoIiwib25CZWZvcmVVcGxvYWQiLCJmaWxlIiwic2l6ZSIsInRlc3QiLCJleHQiLCJpc0NsaWVudCIsInN1YnNjcmliZSIsImlzU2VydmVyIiwiTGlua3MiLCJjaGVjayIsIm1ldGhvZHMiLCJ0aXRsZSIsInVybCIsImNyZWF0ZWRBdCIsIkRhdGUiLCJNYXBzIiwiYWxsb3dDbGllbnQiLCJhcmd1bWVudCIsImRvd25sb2FkUm91dGUiLCJleHRlbnNpb24iLCJnZXRNYXBMaW5rIiwibWFwSWQiLCJ2YWxpZGFkZUlkIiwidmFsaWRhdGUiLCJrZXlzIiwiY29uc29sZSIsImxvZyIsIm15TWFwIiwiVGFza3MiLCJUZWFtIiwiVGVhbVNjaGVtYSIsImZvcm1hdGlvbiIsIlJvbGVzIiwic3RhcnR1cCIsInNldERlZmF1bHRNZXNzYWdlcyIsImluaXRpYWxMYW5ndWFnZSIsIm1lc3NhZ2VzIiwiZW4iLCJ1cGxvYWRFcnJvciIsInJvbGVzIiwiY291bnQiLCJjcmVhdGVSb2xlIiwiQWNjb3VudHMiLCJvbkNyZWF0ZVVzZXIiLCJvcHRpb25zIiwidXNlciIsImRhdGEiLCJmb3JFYWNoIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsTUFBSjtBQUFXSCxNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLFFBQU0sQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFVBQU0sR0FBQ0QsQ0FBUDtBQUFTOztBQUFwQixDQUEzQixFQUFpRCxDQUFqRDtBQUczRUgsTUFBTSxDQUFDSyxPQUFQLENBQWUsUUFBZixFQUF5QixZQUFZO0FBQ25DLFNBQU9ELE1BQU0sQ0FBQ0UsSUFBUCxDQUFZLEVBQVosQ0FBUDtBQUNELENBRkQsRTs7Ozs7Ozs7Ozs7QUNIQUwsTUFBTSxDQUFDTSxNQUFQLENBQWM7QUFBQ0gsUUFBTSxFQUFDLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJSSxLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sT0FBSyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlNLFlBQUo7QUFBaUJSLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ1EsU0FBTyxDQUFDUCxDQUFELEVBQUc7QUFBQ00sZ0JBQVksR0FBQ04sQ0FBYjtBQUFlOztBQUEzQixDQUEzQixFQUF3RCxDQUF4RDtBQUEyRCxJQUFJUSxRQUFKO0FBQWFWLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHdCQUFaLEVBQXFDO0FBQUNTLFVBQVEsQ0FBQ1IsQ0FBRCxFQUFHO0FBQUNRLFlBQVEsR0FBQ1IsQ0FBVDtBQUFXOztBQUF4QixDQUFyQyxFQUErRCxDQUEvRDtBQUFrRSxJQUFJUyxNQUFKO0FBQVdYLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHFCQUFaLEVBQWtDO0FBQUNVLFFBQU0sQ0FBQ1QsQ0FBRCxFQUFHO0FBQUNTLFVBQU0sR0FBQ1QsQ0FBUDtBQUFTOztBQUFwQixDQUFsQyxFQUF3RCxDQUF4RDtBQUtyUU0sWUFBWSxDQUFDSSxhQUFiLENBQTJCLENBQUMsVUFBRCxDQUEzQjtBQUVPLE1BQU1ULE1BQU0sR0FBRyxJQUFJSSxLQUFLLENBQUNNLFVBQVYsQ0FBcUIsUUFBckIsQ0FBZjtBQUVQVixNQUFNLENBQUNXLEtBQVAsQ0FBYTtBQUNUQyxRQUFNLEVBQUUsWUFBVTtBQUNkLFdBQU8sSUFBUDtBQUNILEdBSFE7QUFJVEMsUUFBTSxFQUFFLFlBQVU7QUFDZCxXQUFPLElBQVA7QUFDSCxHQU5RO0FBT1RDLFFBQU0sRUFBRSxZQUFVO0FBQ2QsV0FBTyxJQUFQO0FBQ0g7QUFUUSxDQUFiO0FBWUFDLFlBQVksR0FBRyxJQUFJVixZQUFKLENBQWlCO0FBQzVCVyxNQUFJLEVBQUU7QUFDRkMsUUFBSSxFQUFFQyxNQURKO0FBRUZDLFNBQUssRUFBRSxpQkFGTDtBQUdGQyxPQUFHLEVBQUU7QUFISCxHQURzQjtBQU01QkMsV0FBUyxFQUFFO0FBQ1BKLFFBQUksRUFBRUssT0FEQztBQUVQQyxZQUFRLEVBQUU7QUFGSCxHQU5pQjtBQVU1QkMsU0FBTyxFQUFFO0FBQ0xQLFFBQUksRUFBRUMsTUFERDtBQUVMTyxZQUFRLEVBQUU7QUFDTkMsa0JBQVksRUFBRTtBQUNWVCxZQUFJLEVBQUUsWUFESTtBQUVWVSxrQkFBVSxFQUFFLFFBRkY7QUFHVjtBQUNBO0FBQ0FDLG9CQUFZLEVBQUU7QUFBRTtBQUNaQyxjQUFJLEVBQUUsRUFESTtBQUVWQyxrQkFBUSxFQUFFLEtBRkE7QUFHVkMsbUJBQVMsRUFBRSxLQUhEO0FBSVZDLGlCQUFPLEVBQUUsU0FKQztBQUtWQyxtQkFBUyxFQUFFLFNBTEQ7QUFNVkMseUJBQWUsRUFBRTtBQU5QO0FBTEo7QUFEUjtBQUZMO0FBVm1CLENBQWpCLENBQWY7QUErQkFsQyxNQUFNLENBQUNtQyxZQUFQLENBQW9CcEIsWUFBcEIsRTs7Ozs7Ozs7Ozs7QUNwREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJOzs7Ozs7Ozs7OztBQ1BBbEIsTUFBTSxDQUFDTSxNQUFQLENBQWM7QUFBQ0ssUUFBTSxFQUFDLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJWixNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlxQyxlQUFKO0FBQW9CdkMsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ3NDLGlCQUFlLENBQUNyQyxDQUFELEVBQUc7QUFBQ3FDLG1CQUFlLEdBQUNyQyxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBbEMsRUFBMEUsQ0FBMUU7QUFHaEgsTUFBTVMsTUFBTSxHQUFHLElBQUk0QixlQUFKLENBQW9CO0FBQ3RDQyxnQkFBYyxFQUFFLFFBRHNCO0FBRXRDQyxpQkFBZSxFQUFFLElBRnFCO0FBRWY7QUFDdkJDLGFBQVcsRUFBRSxnQ0FIeUI7O0FBR1M7QUFDL0NDLGdCQUFjLENBQUNDLElBQUQsRUFBTztBQUNqQjtBQUNBLFFBQUlBLElBQUksQ0FBQ0MsSUFBTCxJQUFhLFFBQWIsSUFBeUIsZ0JBQWdCQyxJQUFoQixDQUFxQkYsSUFBSSxDQUFDRyxHQUExQixDQUE3QixFQUE2RDtBQUN6RCxhQUFPLElBQVA7QUFDSCxLQUZELE1BRU87QUFDSCxhQUFPLHdEQUFQO0FBQ0g7QUFDSjs7QUFYcUMsQ0FBcEIsQ0FBZjs7QUFjUCxJQUFJaEQsTUFBTSxDQUFDaUQsUUFBWCxFQUFxQjtBQUNqQmpELFFBQU0sQ0FBQ2tELFNBQVAsQ0FBaUIsa0JBQWpCO0FBQ0g7O0FBRUQsSUFBSWxELE1BQU0sQ0FBQ21ELFFBQVgsRUFBcUI7QUFDakJuRCxRQUFNLENBQUNLLE9BQVAsQ0FBZSxrQkFBZixFQUFtQyxNQUFNO0FBQ3JDLFdBQU9PLE1BQU0sQ0FBQ21CLFVBQVAsQ0FBa0J6QixJQUFsQixDQUF1QixFQUF2QixDQUFQO0FBQ0gsR0FGRDtBQUdILEM7Ozs7Ozs7Ozs7O0FDekJELElBQUlOLE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWlELEtBQUo7QUFBVW5ELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGFBQVosRUFBMEI7QUFBQ2tELE9BQUssQ0FBQ2pELENBQUQsRUFBRztBQUFDaUQsU0FBSyxHQUFDakQsQ0FBTjtBQUFROztBQUFsQixDQUExQixFQUE4QyxDQUE5QztBQUsxRUgsTUFBTSxDQUFDSyxPQUFQLENBQWUsV0FBZixFQUE0QixZQUFZO0FBQ3RDLFNBQU8rQyxLQUFLLENBQUM5QyxJQUFOLEVBQVA7QUFDRCxDQUZELEU7Ozs7Ozs7Ozs7O0FDTEFMLE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUM2QyxPQUFLLEVBQUMsTUFBSUE7QUFBWCxDQUFkO0FBQWlDLElBQUk1QyxLQUFKO0FBQVVQLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ00sT0FBSyxDQUFDTCxDQUFELEVBQUc7QUFBQ0ssU0FBSyxHQUFDTCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBSXBDLE1BQU1pRCxLQUFLLEdBQUcsSUFBSTVDLEtBQUssQ0FBQ00sVUFBVixDQUFxQixPQUFyQixDQUFkLEM7Ozs7Ozs7Ozs7O0FDSlAsSUFBSWQsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJa0QsS0FBSjtBQUFVcEQsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDbUQsT0FBSyxDQUFDbEQsQ0FBRCxFQUFHO0FBQUNrRCxTQUFLLEdBQUNsRCxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQWtELElBQUlpRCxLQUFKO0FBQVVuRCxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNrRCxPQUFLLENBQUNqRCxDQUFELEVBQUc7QUFBQ2lELFNBQUssR0FBQ2pELENBQU47QUFBUTs7QUFBbEIsQ0FBekIsRUFBNkMsQ0FBN0M7QUFNdElILE1BQU0sQ0FBQ3NELE9BQVAsQ0FBZTtBQUNiLGlCQUFlQyxLQUFmLEVBQXNCQyxHQUF0QixFQUEyQjtBQUN6QkgsU0FBSyxDQUFDRyxHQUFELEVBQU1sQyxNQUFOLENBQUw7QUFDQStCLFNBQUssQ0FBQ0UsS0FBRCxFQUFRakMsTUFBUixDQUFMO0FBRUEsV0FBTzhCLEtBQUssQ0FBQ3BDLE1BQU4sQ0FBYTtBQUNsQndDLFNBRGtCO0FBRWxCRCxXQUZrQjtBQUdsQkUsZUFBUyxFQUFFLElBQUlDLElBQUo7QUFITyxLQUFiLENBQVA7QUFLRDs7QUFWWSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTkEsSUFBSTFELE1BQUo7QUFBV0MsTUFBTSxDQUFDQyxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRixRQUFNLENBQUNHLENBQUQsRUFBRztBQUFDSCxVQUFNLEdBQUNHLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXdELElBQUo7QUFBUzFELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFlBQVosRUFBeUI7QUFBQ3lELE1BQUksQ0FBQ3hELENBQUQsRUFBRztBQUFDd0QsUUFBSSxHQUFDeEQsQ0FBTDtBQUFPOztBQUFoQixDQUF6QixFQUEyQyxDQUEzQztBQUd6RXdELElBQUksQ0FBQ0MsV0FBTDtBQUVBNUQsTUFBTSxDQUFDSyxPQUFQLENBQWUsZ0JBQWYsRUFBaUMsVUFBU3dELFFBQVQsRUFBa0I7QUFDL0MsU0FBT0YsSUFBSSxDQUFDNUIsVUFBTCxDQUFnQnpCLElBQWhCLENBQXFCLEVBQXJCLENBQVA7QUFDSCxDQUZELEU7Ozs7Ozs7Ozs7O0FDTEFMLE1BQU0sQ0FBQ00sTUFBUCxDQUFjO0FBQUNvRCxNQUFJLEVBQUMsTUFBSUE7QUFBVixDQUFkO0FBQStCLElBQUkzRCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlxQyxlQUFKO0FBQW9CdkMsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ3NDLGlCQUFlLENBQUNyQyxDQUFELEVBQUc7QUFBQ3FDLG1CQUFlLEdBQUNyQyxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBbEMsRUFBMEUsQ0FBMUU7QUFBNkVGLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVo7QUFLekwsTUFBTXlELElBQUksR0FBRyxJQUFJbkIsZUFBSixDQUFvQjtBQUNwQ0MsZ0JBQWMsRUFBRSxNQURvQjtBQUVwQ0MsaUJBQWUsRUFBRSxJQUZtQjtBQUdwQ29CLGVBQWEsRUFBRSxVQUhxQjs7QUFLcENsQixnQkFBYyxDQUFDQyxJQUFELEVBQU07QUFDaEIsUUFBR0EsSUFBSSxDQUFDQyxJQUFMLElBQWEsUUFBYixJQUF5QixnQkFBZ0JDLElBQWhCLENBQXFCRixJQUFJLENBQUNrQixTQUExQixDQUE1QixFQUFpRTtBQUM3RCxhQUFPLElBQVA7QUFDSDs7QUFDRCxXQUFPLHNDQUFQO0FBQ0g7O0FBVm1DLENBQXBCLENBQWIsQzs7Ozs7Ozs7Ozs7QUNMUCxJQUFJL0QsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJTSxZQUFKO0FBQWlCUixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNRLFNBQU8sQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNNLGdCQUFZLEdBQUNOLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSXdELElBQUo7QUFBUzFELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLFdBQVosRUFBd0I7QUFBQ3lELE1BQUksQ0FBQ3hELENBQUQsRUFBRztBQUFDd0QsUUFBSSxHQUFDeEQsQ0FBTDtBQUFPOztBQUFoQixDQUF4QixFQUEwQyxDQUExQztBQUlySkgsTUFBTSxDQUFDc0QsT0FBUCxDQUFlO0FBQ1hVLFlBQVUsRUFBQyxVQUFTQyxLQUFULEVBQWU7QUFDdEJDLGNBQVUsR0FBRyxJQUFJekQsWUFBSixDQUFpQjtBQUFDd0QsV0FBSyxFQUFFO0FBQUU1QyxZQUFJLEVBQUVDO0FBQVI7QUFBUixLQUFqQixDQUFiO0FBQ0FiLGdCQUFZLENBQUMwRCxRQUFiLENBQXNCRixLQUF0QixFQUE2QkMsVUFBN0IsRUFBeUM7QUFBQ0UsVUFBSSxFQUFFLENBQUMsT0FBRDtBQUFQLEtBQXpDO0FBQ0FDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZTCxLQUFaO0FBQ0FNLFNBQUssR0FBR1osSUFBSSxDQUFDNUIsVUFBTCxDQUFnQnpCLElBQWhCLENBQXFCMkQsS0FBSyxDQUFDLE9BQUQsQ0FBMUIsQ0FBUjtBQUNBLFdBQU9NLEtBQVA7QUFDSDtBQVBVLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJdkUsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJcUUsS0FBSjtBQUFVdkUsTUFBTSxDQUFDQyxJQUFQLENBQVksYUFBWixFQUEwQjtBQUFDc0UsT0FBSyxDQUFDckUsQ0FBRCxFQUFHO0FBQUNxRSxTQUFLLEdBQUNyRSxDQUFOO0FBQVE7O0FBQWxCLENBQTFCLEVBQThDLENBQTlDO0FBRzFFSCxNQUFNLENBQUNLLE9BQVAsQ0FBZSxXQUFmLEVBQTRCLFlBQVk7QUFDdEMsU0FBT21FLEtBQUssQ0FBQ2xFLElBQU4sRUFBUDtBQUNELENBRkQsRTs7Ozs7Ozs7Ozs7QUNIQUwsTUFBTSxDQUFDTSxNQUFQLENBQWM7QUFBQ2lFLE9BQUssRUFBQyxNQUFJQTtBQUFYLENBQWQ7QUFBaUMsSUFBSWhFLEtBQUo7QUFBVVAsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTSxPQUFLLENBQUNMLENBQUQsRUFBRztBQUFDSyxTQUFLLEdBQUNMLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFFcEMsTUFBTXFFLEtBQUssR0FBRyxJQUFJaEUsS0FBSyxDQUFDTSxVQUFWLENBQXFCLE9BQXJCLENBQWQsQzs7Ozs7Ozs7Ozs7QUNGUCxJQUFJZCxNQUFKO0FBQVdDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVosRUFBNEI7QUFBQ0YsUUFBTSxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsVUFBTSxHQUFDRyxDQUFQO0FBQVM7O0FBQXBCLENBQTVCLEVBQWtELENBQWxEO0FBQXFELElBQUlzRSxJQUFKO0FBQVN4RSxNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUN1RSxNQUFJLENBQUN0RSxDQUFELEVBQUc7QUFBQ3NFLFFBQUksR0FBQ3RFLENBQUw7QUFBTzs7QUFBaEIsQ0FBekIsRUFBMkMsQ0FBM0M7QUFHekVILE1BQU0sQ0FBQ0ssT0FBUCxDQUFlLE1BQWYsRUFBdUIsWUFBWTtBQUNqQyxTQUFPb0UsSUFBSSxDQUFDbkUsSUFBTCxDQUFVLEVBQVYsQ0FBUDtBQUNELENBRkQsRTs7Ozs7Ozs7Ozs7QUNIQUwsTUFBTSxDQUFDTSxNQUFQLENBQWM7QUFBQ2tFLE1BQUksRUFBQyxNQUFJQTtBQUFWLENBQWQ7QUFBK0IsSUFBSWpFLEtBQUo7QUFBVVAsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDTSxPQUFLLENBQUNMLENBQUQsRUFBRztBQUFDSyxTQUFLLEdBQUNMLENBQU47QUFBUTs7QUFBbEIsQ0FBM0IsRUFBK0MsQ0FBL0M7QUFBa0QsSUFBSU0sWUFBSjtBQUFpQlIsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDUSxTQUFPLENBQUNQLENBQUQsRUFBRztBQUFDTSxnQkFBWSxHQUFDTixDQUFiO0FBQWU7O0FBQTNCLENBQTNCLEVBQXdELENBQXhEO0FBQTJELElBQUlRLFFBQUo7QUFBYVYsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVosRUFBcUM7QUFBQ1MsVUFBUSxDQUFDUixDQUFELEVBQUc7QUFBQ1EsWUFBUSxHQUFDUixDQUFUO0FBQVc7O0FBQXhCLENBQXJDLEVBQStELENBQS9EO0FBQWtFLElBQUlTLE1BQUo7QUFBV1gsTUFBTSxDQUFDQyxJQUFQLENBQVkscUJBQVosRUFBa0M7QUFBQ1UsUUFBTSxDQUFDVCxDQUFELEVBQUc7QUFBQ1MsVUFBTSxHQUFDVCxDQUFQO0FBQVM7O0FBQXBCLENBQWxDLEVBQXdELENBQXhEO0FBS2pRTSxZQUFZLENBQUNJLGFBQWIsQ0FBMkIsQ0FBQyxVQUFELENBQTNCO0FBRU8sTUFBTTRELElBQUksR0FBRyxJQUFJakUsS0FBSyxDQUFDTSxVQUFWLENBQXFCLE1BQXJCLENBQWI7QUFFUDJELElBQUksQ0FBQzFELEtBQUwsQ0FBVztBQUNQQyxRQUFNLEVBQUUsWUFBVTtBQUNkLFdBQU8sSUFBUDtBQUNILEdBSE07QUFJUEMsUUFBTSxFQUFFLFlBQVU7QUFDZCxXQUFPLElBQVA7QUFDSCxHQU5NO0FBT1BDLFFBQU0sRUFBRSxZQUFVO0FBQ2QsV0FBTyxJQUFQO0FBQ0g7QUFUTSxDQUFYO0FBWUF3RCxVQUFVLEdBQUcsSUFBSWpFLFlBQUosQ0FBaUI7QUFDMUJXLE1BQUksRUFBRTtBQUNGQyxRQUFJLEVBQUVDLE1BREo7QUFFRkMsU0FBSyxFQUFFLE1BRkw7QUFHRkMsT0FBRyxFQUFFO0FBSEgsR0FEb0I7QUFNMUJtRCxXQUFTLEVBQUU7QUFDUHRELFFBQUksRUFBRUMsTUFEQztBQUVQQyxTQUFLLEVBQUUsVUFGQTtBQUdQSSxZQUFRLEVBQUUsSUFISDtBQUlQSCxPQUFHLEVBQUU7QUFKRSxHQU5lO0FBWTFCdEIsTUFBSSxFQUFFO0FBQ0ZtQixRQUFJLEVBQUVDLE1BREo7QUFFRkMsU0FBSyxFQUFFLE1BRkw7QUFHRkMsT0FBRyxFQUFFO0FBSEgsR0Fab0I7QUFpQjFCSSxTQUFPLEVBQUU7QUFDTFAsUUFBSSxFQUFFQyxNQUREO0FBRUxPLFlBQVEsRUFBRTtBQUNOQyxrQkFBWSxFQUFFO0FBQ1ZULFlBQUksRUFBRSxZQURJO0FBRVZVLGtCQUFVLEVBQUUsUUFGRjtBQUdWO0FBQ0E7QUFDQUMsb0JBQVksRUFBRTtBQUFFO0FBQ1pDLGNBQUksRUFBRSxFQURJO0FBRVZDLGtCQUFRLEVBQUUsS0FGQTtBQUdWQyxtQkFBUyxFQUFFLEtBSEQ7QUFJVkMsaUJBQU8sRUFBRSxTQUpDO0FBS1ZDLG1CQUFTLEVBQUUsU0FMRDtBQU1WQyx5QkFBZSxFQUFFO0FBTlA7QUFMSjtBQURSO0FBRkw7QUFqQmlCLENBQWpCLENBQWI7QUF1Q0FtQyxJQUFJLENBQUNsQyxZQUFMLENBQWtCbUMsVUFBbEIsRTs7Ozs7Ozs7Ozs7QUM1REE7QUFDQSx3Qzs7Ozs7Ozs7Ozs7QUNEQSxJQUFJMUUsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJaUQsS0FBSjtBQUFVbkQsTUFBTSxDQUFDQyxJQUFQLENBQVksMEJBQVosRUFBdUM7QUFBQ2tELE9BQUssQ0FBQ2pELENBQUQsRUFBRztBQUFDaUQsU0FBSyxHQUFDakQsQ0FBTjtBQUFROztBQUFsQixDQUF2QyxFQUEyRCxDQUEzRDtBQUE4RCxJQUFJeUUsS0FBSjtBQUFVM0UsTUFBTSxDQUFDQyxJQUFQLENBQVksdUJBQVosRUFBb0M7QUFBQzBFLE9BQUssQ0FBQ3pFLENBQUQsRUFBRztBQUFDeUUsU0FBSyxHQUFDekUsQ0FBTjtBQUFROztBQUFsQixDQUFwQyxFQUF3RCxDQUF4RDtBQUEyRCxJQUFJTSxZQUFKO0FBQWlCUixNQUFNLENBQUNDLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNRLFNBQU8sQ0FBQ1AsQ0FBRCxFQUFHO0FBQUNNLGdCQUFZLEdBQUNOLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFPOU5ILE1BQU0sQ0FBQzZFLE9BQVAsQ0FBZSxNQUFNO0FBQ2pCO0FBQ0FwRSxjQUFZLENBQUNxRSxrQkFBYixDQUFnQztBQUM1QkMsbUJBQWUsRUFBRSxJQURXO0FBRTVCQyxZQUFRLEVBQUU7QUFDTkMsUUFBRSxFQUFFO0FBQ0FDLG1CQUFXLEVBQUUsV0FEYixDQUMwQjs7QUFEMUI7QUFERTtBQUZrQixHQUFoQyxFQUZpQixDQVVqQjs7QUFDQSxNQUFJQyxLQUFLLEdBQUduRixNQUFNLENBQUNtRixLQUFQLENBQWE3RSxJQUFiLENBQWtCLEVBQWxCLEVBQXNCOEUsS0FBdEIsRUFBWjs7QUFDQSxNQUFJRCxLQUFLLEdBQUcsQ0FBWixFQUFlO0FBQ1hkLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGtDQUFaO0FBQ0gsR0FGRCxNQUVPO0FBQ0hNLFNBQUssQ0FBQ1MsVUFBTixDQUFpQixXQUFqQjtBQUNBVCxTQUFLLENBQUNTLFVBQU4sQ0FBaUIsYUFBakI7QUFDQVQsU0FBSyxDQUFDUyxVQUFOLENBQWlCLGVBQWpCO0FBQ0gsR0FsQmdCLENBbUJqQjs7O0FBQ0FDLFVBQVEsQ0FBQ0MsWUFBVCxDQUFzQixVQUFTQyxPQUFULEVBQWtCQyxJQUFsQixFQUF1QjtBQUN6Q0EsUUFBSSxDQUFDTixLQUFMLEdBQWEsQ0FBQyxXQUFELENBQWI7QUFDQSxXQUFPTSxJQUFQO0FBQ0gsR0FIRCxFQXBCaUIsQ0F3QmpCOztBQUNBLE1BQUlyQyxLQUFLLENBQUM5QyxJQUFOLEdBQWE4RSxLQUFiLE9BQXlCLENBQTdCLEVBQWdDO0FBQzVCLFVBQU1NLElBQUksR0FBRyxDQUNUO0FBQ0luQyxXQUFLLEVBQUUsaUJBRFg7QUFFSUMsU0FBRyxFQUFFLDRCQUZUO0FBR0lDLGVBQVMsRUFBRSxJQUFJQyxJQUFKO0FBSGYsS0FEUyxFQU1UO0FBQ0lILFdBQUssRUFBRSxrQkFEWDtBQUVJQyxTQUFHLEVBQUUseUJBRlQ7QUFHSUMsZUFBUyxFQUFFLElBQUlDLElBQUo7QUFIZixLQU5TLEVBV1Q7QUFDSUgsV0FBSyxFQUFFLGVBRFg7QUFFSUMsU0FBRyxFQUFFLHlCQUZUO0FBR0lDLGVBQVMsRUFBRSxJQUFJQyxJQUFKO0FBSGYsS0FYUyxFQWdCVDtBQUNJSCxXQUFLLEVBQUUsYUFEWDtBQUVJQyxTQUFHLEVBQUUsMkJBRlQ7QUFHSUMsZUFBUyxFQUFFLElBQUlDLElBQUo7QUFIZixLQWhCUyxDQUFiO0FBdUJBZ0MsUUFBSSxDQUFDQyxPQUFMLENBQWF6RixJQUFJLElBQUlrRCxLQUFLLENBQUNwQyxNQUFOLENBQWFkLElBQWIsQ0FBckI7QUFDSDtBQUNKLENBbkRELEU7Ozs7Ozs7Ozs7O0FDUEFELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGVBQVo7QUFBNkJELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLG1CQUFaLEU7Ozs7Ozs7Ozs7O0FDQTdCRCxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWjtBQUEwQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVksd0NBQVo7QUFBc0RELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDBCQUFaO0FBQXdDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSx3Q0FBWjtBQUFzREQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVo7QUFBc0NELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVDQUFaO0FBQXFERCxNQUFNLENBQUNDLElBQVAsQ0FBWSw0QkFBWjtBQUEwQ0QsTUFBTSxDQUFDQyxJQUFQLENBQVkseUNBQVo7QUFBdURELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLDRCQUFaO0FBQTBDRCxNQUFNLENBQUNDLElBQVAsQ0FBWSx5Q0FBWjtBQUF1REQsTUFBTSxDQUFDQyxJQUFQLENBQVksd0JBQVo7QUFBc0NELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVDQUFaLEU7Ozs7Ozs7Ozs7O0FDQWpnQkQsTUFBTSxDQUFDQyxJQUFQLENBQVkseUJBQVo7QUFBdUNELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHVCQUFaLEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgQ2hhcnRzIH0gZnJvbSAnLi4vY2hhcnRzLmpzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ0NoYXJ0cycsIGZ1bmN0aW9uICgpIHtcbiAgcmV0dXJuIENoYXJ0cy5maW5kKHt9KTtcbn0pO1xuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IHsgQXV0b0Zvcm0gfSBmcm9tICdtZXRlb3IvYWxkZWVkOmF1dG9mb3JtJztcbmltcG9ydCB7IEltYWdlcyB9IGZyb20gJy4uL2ltYWdlcy9pbWFnZXMuanMnO1xuXG5TaW1wbGVTY2hlbWEuZXh0ZW5kT3B0aW9ucyhbJ2F1dG9mb3JtJ10pO1xuXG5leHBvcnQgY29uc3QgQ2hhcnRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ0NoYXJ0cycpO1xuXG5DaGFydHMuYWxsb3coe1xuICAgIGluc2VydDogZnVuY3Rpb24oKXtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSxcbiAgICB1cGRhdGU6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH0sXG4gICAgcmVtb3ZlOiBmdW5jdGlvbigpe1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG59KTtcblxuQ2hhcnRzU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgbmFtZToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGxhYmVsOiAnTm9tZSBkbyBHcsOhZmljbycsXG4gICAgICAgIG1heDogMzBcbiAgICB9LFxuICAgIGF2YWlsYWJsZToge1xuICAgICAgICB0eXBlOiBCb29sZWFuLFxuICAgICAgICBvcHRpb25hbDogdHJ1ZSxcbiAgICB9LFxuICAgIHBpY3R1cmU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBhdXRvZm9ybToge1xuICAgICAgICAgICAgYWZGaWVsZElucHV0OiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2ZpbGVVcGxvYWQnLFxuICAgICAgICAgICAgICAgIGNvbGxlY3Rpb246ICdJbWFnZXMnLFxuICAgICAgICAgICAgICAgIC8vIHVwbG9hZFRlbXBsYXRlOiAndXBsb2FkRmllbGQnLCAvLyA8LSBPcHRpb25hbFxuICAgICAgICAgICAgICAgIC8vIHByZXZpZXdUZW1wbGF0ZTogJ3VwbG9hZFByZXZpZXcnLCAvLyA8LSBPcHRpb25hbFxuICAgICAgICAgICAgICAgIGluc2VydENvbmZpZzogeyAvLyA8LSBPcHRpb25hbCwgLmluc2VydCgpIG1ldGhvZCBvcHRpb25zLCBzZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9WZWxpb3ZHcm91cC9NZXRlb3ItRmlsZXMvd2lraS9JbnNlcnQtKFVwbG9hZClcbiAgICAgICAgICAgICAgICAgICAgbWV0YToge30sXG4gICAgICAgICAgICAgICAgICAgIGlzQmFzZTY0OiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNwb3J0OiAnZGRwJyxcbiAgICAgICAgICAgICAgICAgICAgc3RyZWFtczogJ2R5bmFtaWMnLFxuICAgICAgICAgICAgICAgICAgICBjaHVua1NpemU6ICdkeW5hbWljJyxcbiAgICAgICAgICAgICAgICAgICAgYWxsb3dXZWJXb3JrZXJzOiB0cnVlXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufSk7XG5cbkNoYXJ0cy5hdHRhY2hTY2hlbWEoQ2hhcnRzU2NoZW1hKTtcbiIsIi8vIGltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuLy8gaW1wb3J0IHsgSW1hZ2VzIH0gZnJvbSAnLi4vaW1hZ2VzLmpzJztcbi8vXG4vLyBpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG4vLyAgIE1ldGVvci5wdWJsaXNoKCdmaWxlcy5pbWFnZXMuYWxsJywgZnVuY3Rpb24gKCkge1xuLy8gICAgIHJldHVybiBJbWFnZXMuZmluZCgpLmN1cnNvcjtcbi8vICAgfSk7XG4vLyB9XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEZpbGVzQ29sbGVjdGlvbiB9IGZyb20gJ21ldGVvci9vc3RyaW86ZmlsZXMnO1xuXG5leHBvcnQgY29uc3QgSW1hZ2VzID0gbmV3IEZpbGVzQ29sbGVjdGlvbih7XG4gICAgY29sbGVjdGlvbk5hbWU6ICdJbWFnZXMnLFxuICAgIGFsbG93Q2xpZW50Q29kZTogdHJ1ZSwgLy8gUmVxdWlyZWQgdG8gbGV0IHlvdSByZW1vdmUgdXBsb2FkZWQgZmlsZSxcbiAgICBzdG9yYWdlUGF0aDogJy92YXIvd3d3L3VyYmFudXMvcHVibGljL2ltYWdlcycsIC8vbXVzdCBiZSB0aGUgc2FtZSBvbiBkb2NrZXJmaWxlXG4gICAgb25CZWZvcmVVcGxvYWQoZmlsZSkge1xuICAgICAgICAvLyBBbGxvdyB1cGxvYWQgZmlsZXMgdW5kZXIgMTBNQiwgYW5kIG9ubHkgaW4gcG5nL2pwZy9qcGVnIGZvcm1hdHNcbiAgICAgICAgaWYgKGZpbGUuc2l6ZSA8PSAxMDQ4NTc2MCAmJiAvcG5nfGpwZ3xqcGVnL2kudGVzdChmaWxlLmV4dCkpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuICdQbGVhc2UgdXBsb2FkIGltYWdlLCB3aXRoIHNpemUgZXF1YWwgb3IgbGVzcyB0aGFuIDEwTUInO1xuICAgICAgICB9XG4gICAgfVxufSk7XG5cbmlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgICBNZXRlb3Iuc3Vic2NyaWJlKCdmaWxlcy5pbWFnZXMuYWxsJyk7XG59XG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICBNZXRlb3IucHVibGlzaCgnZmlsZXMuaW1hZ2VzLmFsbCcsICgpID0+IHtcbiAgICAgICAgcmV0dXJuIEltYWdlcy5jb2xsZWN0aW9uLmZpbmQoe30pO1xuICAgIH0pO1xufVxuIiwiLy8gQWxsIGxpbmtzLXJlbGF0ZWQgcHVibGljYXRpb25zXG5cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTGlua3MgfSBmcm9tICcuLi9saW5rcy5qcyc7XG5cbk1ldGVvci5wdWJsaXNoKCdsaW5rcy5hbGwnLCBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBMaW5rcy5maW5kKCk7XG59KTtcbiIsIi8vIERlZmluaXRpb24gb2YgdGhlIGxpbmtzIGNvbGxlY3Rpb25cblxuaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuXG5leHBvcnQgY29uc3QgTGlua3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbGlua3MnKTtcbiIsIi8vIE1ldGhvZHMgcmVsYXRlZCB0byBsaW5rc1xuXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcbmltcG9ydCB7IExpbmtzIH0gZnJvbSAnLi9saW5rcy5qcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgJ2xpbmtzLmluc2VydCcodGl0bGUsIHVybCkge1xuICAgIGNoZWNrKHVybCwgU3RyaW5nKTtcbiAgICBjaGVjayh0aXRsZSwgU3RyaW5nKTtcblxuICAgIHJldHVybiBMaW5rcy5pbnNlcnQoe1xuICAgICAgdXJsLFxuICAgICAgdGl0bGUsXG4gICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgfSk7XG4gIH0sXG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgTWFwcyB9IGZyb20gJy4uL21hcHMuanMnO1xuXG5NYXBzLmFsbG93Q2xpZW50KCk7XG5cbk1ldGVvci5wdWJsaXNoKFwiZmlsZXMubWFwcy5hbGxcIiwgZnVuY3Rpb24oYXJndW1lbnQpe1xuICAgIHJldHVybiBNYXBzLmNvbGxlY3Rpb24uZmluZCh7fSk7XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgRmlsZXNDb2xsZWN0aW9uIH0gZnJvbSAnbWV0ZW9yL29zdHJpbzpmaWxlcyc7XG5pbXBvcnQgJy4vbWV0aG9kcy5qcyc7XG5cblxuZXhwb3J0IGNvbnN0IE1hcHMgPSBuZXcgRmlsZXNDb2xsZWN0aW9uKHtcbiAgICBjb2xsZWN0aW9uTmFtZTogJ01hcHMnLFxuICAgIGFsbG93Q2xpZW50Q29kZTogdHJ1ZSxcbiAgICBkb3dubG9hZFJvdXRlOiAnL3B1YmxpYy8nLFxuXG4gICAgb25CZWZvcmVVcGxvYWQoZmlsZSl7XG4gICAgICAgIGlmKGZpbGUuc2l6ZSA8PSAxMDQ4NTc2MCAmJiAvanNvbnxnZW9qc29uL2kudGVzdChmaWxlLmV4dGVuc2lvbikpe1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICdGYXZvciBmYXplciB1cGxvYWQgZGUgZ2VvanNvbiB2w6FsaWRvJztcbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IFNpbXBsZVNjaGVtYSBmcm9tICdzaW1wbC1zY2hlbWEnO1xuaW1wb3J0IHsgTWFwcyB9IGZyb20gJy4vbWFwcy5qcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICBnZXRNYXBMaW5rOmZ1bmN0aW9uKG1hcElkKXtcbiAgICAgICAgdmFsaWRhZGVJZCA9IG5ldyBTaW1wbGVTY2hlbWEoe21hcElkOiB7IHR5cGU6IFN0cmluZyB9IH0pO1xuICAgICAgICBTaW1wbGVTY2hlbWEudmFsaWRhdGUobWFwSWQsIHZhbGlkYWRlSWQsIHtrZXlzOiBbXCJtYXBJZFwiXX0pO1xuICAgICAgICBjb25zb2xlLmxvZyhtYXBJZCk7XG4gICAgICAgIG15TWFwID0gTWFwcy5jb2xsZWN0aW9uLmZpbmQobWFwSWRbXCJtYXBJZFwiXSk7XG4gICAgICAgIHJldHVybiBteU1hcDtcbiAgICB9XG59KTtcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgVGFza3MgfSBmcm9tICcuLi90YXNrcy5qcyc7XG5cbk1ldGVvci5wdWJsaXNoKCd0YXNrcy5hbGwnLCBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBUYXNrcy5maW5kKCk7XG59KTtcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcblxuZXhwb3J0IGNvbnN0IFRhc2tzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3Rhc2tzJyk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IFRlYW0gfSBmcm9tICcuLi90ZWFtLmpzJztcblxuTWV0ZW9yLnB1Ymxpc2goJ1RlYW0nLCBmdW5jdGlvbiAoKSB7XG4gIHJldHVybiBUZWFtLmZpbmQoe30pO1xufSk7XG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSc7XG5pbXBvcnQgeyBBdXRvRm9ybSB9IGZyb20gJ21ldGVvci9hbGRlZWQ6YXV0b2Zvcm0nO1xuaW1wb3J0IHsgSW1hZ2VzIH0gZnJvbSAnLi4vaW1hZ2VzL2ltYWdlcy5qcyc7XG5cblNpbXBsZVNjaGVtYS5leHRlbmRPcHRpb25zKFsnYXV0b2Zvcm0nXSk7XG5cbmV4cG9ydCBjb25zdCBUZWFtID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ1RlYW0nKTtcblxuVGVhbS5hbGxvdyh7XG4gICAgaW5zZXJ0OiBmdW5jdGlvbigpe1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuICAgIHVwZGF0ZTogZnVuY3Rpb24oKXtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSxcbiAgICByZW1vdmU6IGZ1bmN0aW9uKCl7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn0pO1xuXG5UZWFtU2NoZW1hID0gbmV3IFNpbXBsZVNjaGVtYSh7XG4gICAgbmFtZToge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGxhYmVsOiBcIk5vbWVcIixcbiAgICAgICAgbWF4OiAyMDBcbiAgICB9LFxuICAgIGZvcm1hdGlvbjoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGxhYmVsOiAnRm9ybWHDp8OjbycsXG4gICAgICAgIG9wdGlvbmFsOiB0cnVlLFxuICAgICAgICBtYXg6IDEwMFxuICAgIH0sXG4gICAgbGluazoge1xuICAgICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICAgIGxhYmVsOiBcIkxpbmtcIixcbiAgICAgICAgbWF4OiAyMDBcbiAgICB9LFxuICAgIHBpY3R1cmU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICBhdXRvZm9ybToge1xuICAgICAgICAgICAgYWZGaWVsZElucHV0OiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2ZpbGVVcGxvYWQnLFxuICAgICAgICAgICAgICAgIGNvbGxlY3Rpb246ICdJbWFnZXMnLFxuICAgICAgICAgICAgICAgIC8vIHVwbG9hZFRlbXBsYXRlOiAndXBsb2FkRmllbGQnLCAvLyA8LSBPcHRpb25hbFxuICAgICAgICAgICAgICAgIC8vIHByZXZpZXdUZW1wbGF0ZTogJ3VwbG9hZFByZXZpZXcnLCAvLyA8LSBPcHRpb25hbFxuICAgICAgICAgICAgICAgIGluc2VydENvbmZpZzogeyAvLyA8LSBPcHRpb25hbCwgLmluc2VydCgpIG1ldGhvZCBvcHRpb25zLCBzZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9WZWxpb3ZHcm91cC9NZXRlb3ItRmlsZXMvd2lraS9JbnNlcnQtKFVwbG9hZClcbiAgICAgICAgICAgICAgICAgICAgbWV0YToge30sXG4gICAgICAgICAgICAgICAgICAgIGlzQmFzZTY0OiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNwb3J0OiAnZGRwJyxcbiAgICAgICAgICAgICAgICAgICAgc3RyZWFtczogJ2R5bmFtaWMnLFxuICAgICAgICAgICAgICAgICAgICBjaHVua1NpemU6ICdkeW5hbWljJyxcbiAgICAgICAgICAgICAgICAgICAgYWxsb3dXZWJXb3JrZXJzOiB0cnVlXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG59KTtcblxuVGVhbS5hdHRhY2hTY2hlbWEoVGVhbVNjaGVtYSk7XG4iLCIvLyBJbXBvcnQgbW9kdWxlcyB1c2VkIGJ5IGJvdGggY2xpZW50IGFuZCBzZXJ2ZXIgdGhyb3VnaCBhIHNpbmdsZSBpbmRleCBlbnRyeSBwb2ludFxuLy8gZS5nLiB1c2VyYWNjb3VudHMgY29uZmlndXJhdGlvbiBmaWxlLlxuIiwiLy8gRmlsbCB0aGUgREIgd2l0aCBleGFtcGxlIGRhdGEgb24gc3RhcnR1cFxuXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IExpbmtzIH0gZnJvbSAnLi4vLi4vYXBpL2xpbmtzL2xpbmtzLmpzJztcbmltcG9ydCB7IFJvbGVzIH0gZnJvbSAnbWV0ZW9yL2FsYW5uaW5nOnJvbGVzJztcbmltcG9ydCBTaW1wbGVTY2hlbWEgZnJvbSAnc2ltcGwtc2NoZW1hJztcblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAgIC8vIFNldCBDb25mIGZvciBhdXRvZm9ybS1maWxlcyA8aHR0cHM6Ly9naXRodWIuY29tL1ZlbGlvdkdyb3VwL21ldGVvci1hdXRvZm9ybS1maWxlPlxuICAgIFNpbXBsZVNjaGVtYS5zZXREZWZhdWx0TWVzc2FnZXMoe1xuICAgICAgICBpbml0aWFsTGFuZ3VhZ2U6ICdlbicsXG4gICAgICAgIG1lc3NhZ2VzOiB7XG4gICAgICAgICAgICBlbjoge1xuICAgICAgICAgICAgICAgIHVwbG9hZEVycm9yOiAne3t2YWx1ZX19JywgLy9GaWxlLXVwbG9hZFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIC8vIElmIHRoZSBSb2xlcyBjb2xsZWN0aW9uIGlzIGVtcHR5XG4gICAgdmFyIHJvbGVzID0gTWV0ZW9yLnJvbGVzLmZpbmQoe30pLmNvdW50KCk7XG4gICAgaWYgKHJvbGVzID4gMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhcIlJvbGVzIERlZmluZWQuIERlZmF1bHQgQmVoYXZpb3IuXCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIFJvbGVzLmNyZWF0ZVJvbGUoJ0NvbnZpZGFkbycpO1xuICAgICAgICBSb2xlcy5jcmVhdGVSb2xlKCdDb2xhYm9yYWRvcicpO1xuICAgICAgICBSb2xlcy5jcmVhdGVSb2xlKCdBZG1pbmlzdHJhZG9yJyk7XG4gICAgfVxuICAgIC8vIE1ha2UgbmV3IHVzZXIgYXMgJ0NvbnZpZGFkbyByb2xlJ1xuICAgIEFjY291bnRzLm9uQ3JlYXRlVXNlcihmdW5jdGlvbihvcHRpb25zLCB1c2VyKXtcbiAgICAgICAgdXNlci5yb2xlcyA9IFsnQ29udmlkYWRvJ107XG4gICAgICAgIHJldHVybiB1c2VyO1xuICAgIH0pO1xuICAgIC8vIGlmIHRoZSBMaW5rcyBjb2xsZWN0aW9uIGlzIGVtcHR5XG4gICAgaWYgKExpbmtzLmZpbmQoKS5jb3VudCgpID09PSAwKSB7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGl0bGU6ICdEbyB0aGUgVHV0b3JpYWwnLFxuICAgICAgICAgICAgICAgIHVybDogJ2h0dHBzOi8vd3d3Lm1ldGVvci5jb20vdHJ5JyxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHRpdGxlOiAnRm9sbG93IHRoZSBHdWlkZScsXG4gICAgICAgICAgICAgICAgdXJsOiAnaHR0cDovL2d1aWRlLm1ldGVvci5jb20nLFxuICAgICAgICAgICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGl0bGU6ICdSZWFkIHRoZSBEb2NzJyxcbiAgICAgICAgICAgICAgICB1cmw6ICdodHRwczovL2RvY3MubWV0ZW9yLmNvbScsXG4gICAgICAgICAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0aXRsZTogJ0Rpc2N1c3Npb25zJyxcbiAgICAgICAgICAgICAgICB1cmw6ICdodHRwczovL2ZvcnVtcy5tZXRlb3IuY29tJyxcbiAgICAgICAgICAgICAgICBjcmVhdGVkQXQ6IG5ldyBEYXRlKCksXG4gICAgICAgICAgICB9LFxuICAgICAgICBdO1xuXG4gICAgICAgIGRhdGEuZm9yRWFjaChsaW5rID0+IExpbmtzLmluc2VydChsaW5rKSk7XG4gICAgfVxufSk7XG4iLCIvLyBJbXBvcnQgc2VydmVyIHN0YXJ0dXAgdGhyb3VnaCBhIHNpbmdsZSBpbmRleCBlbnRyeSBwb2ludFxuXG5pbXBvcnQgJy4vZml4dHVyZXMuanMnO1xuaW1wb3J0ICcuL3JlZ2lzdGVyLWFwaS5qcyc7XG4iLCIvLyBSZWdpc3RlciB5b3VyIGFwaXMgaGVyZVxuXG5pbXBvcnQgJy4uLy4uL2FwaS9saW5rcy9tZXRob2RzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2xpbmtzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG4vLyBUYXNrcyBhcGlcbmltcG9ydCAnLi4vLi4vYXBpL3Rhc2tzL3Rhc2tzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3Rhc2tzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG4vLyB0ZWFtIGFwaVxuaW1wb3J0ICcuLi8uLi9hcGkvdGVhbS90ZWFtLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL3RlYW0vc2VydmVyL3B1YmxpY2F0aW9ucy5qcyc7XG5cbi8vIENoYXJ0cyBhcGlcbmltcG9ydCAnLi4vLi4vYXBpL2NoYXJ0cy9jaGFydHMuanMnO1xuaW1wb3J0ICcuLi8uLi9hcGkvY2hhcnRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuXG4vLyBJbWFnZXMgYXBpXG5pbXBvcnQgJy4uLy4uL2FwaS9pbWFnZXMvaW1hZ2VzLmpzJztcbmltcG9ydCAnLi4vLi4vYXBpL2ltYWdlcy9zZXJ2ZXIvcHVibGljYXRpb25zLmpzJztcblxuLy8gTWFwcyBhcGlcbmltcG9ydCAnLi4vLi4vYXBpL21hcHMvbWFwcy5qcyc7XG5pbXBvcnQgJy4uLy4uL2FwaS9tYXBzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMnO1xuIiwiLy8gU2VydmVyIGVudHJ5IHBvaW50LCBpbXBvcnRzIGFsbCBzZXJ2ZXIgY29kZVxuXG5pbXBvcnQgJy9pbXBvcnRzL3N0YXJ0dXAvc2VydmVyJztcbmltcG9ydCAnL2ltcG9ydHMvc3RhcnR1cC9ib3RoJztcbiJdfQ==
